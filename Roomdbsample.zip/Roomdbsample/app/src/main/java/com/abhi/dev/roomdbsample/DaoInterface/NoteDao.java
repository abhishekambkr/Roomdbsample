package com.abhi.dev.roomdbsample.DaoInterface;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;

import com.abhi.dev.roomdbsample.Entities.Note;

@Dao
public interface NoteDao {

    //create methods to insert notes into database
    @Insert
    void insert(Note note);


}

