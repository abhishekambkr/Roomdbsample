package com.abhi.dev.roomdbsample.RoomDatabase;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.content.Context;
import android.os.Environment;

import com.abhi.dev.roomdbsample.DaoInterface.NoteDao;
import com.abhi.dev.roomdbsample.Entities.Note;

import java.io.File;

@Database(entities = Note.class,version = 1)
public abstract class NoteRoomDatabase extends RoomDatabase {

    public abstract NoteDao noteDao();
    //singleton object for Room DB
    //if instance of database exits then it is returned else it will create new instance

    private static volatile NoteRoomDatabase noteRoomInstance;

   public static NoteRoomDatabase getDatabase(final Context context){
        if(noteRoomInstance == null){
            synchronized (NoteRoomDatabase.class){
                if(noteRoomInstance == null){
                 //   copyDatabase(context.getApplicationContext(), "note_database.db");
                    //acquire instance of DB using Room.databaseBuilder()
                    noteRoomInstance = Room.databaseBuilder(context.getApplicationContext(),
                            NoteRoomDatabase.class, "note_database")
                            .build();
                     //note_database
                }
            }
        }
        return noteRoomInstance;
    }

    private static void copyDatabase(Context applicationContext, String dbname) {

        final File dbPath = applicationContext.getDatabasePath(dbname);
    }


}
